const register = ()=>{

    return(


    );
}
export default register;
