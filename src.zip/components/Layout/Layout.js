import Header from './header/header';

const Layout = ()=>{
    return(
        <div>
        <Header/>
        </div>
    );
}
export default Layout;