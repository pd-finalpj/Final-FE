import React from "react";
import LoginImg from "../components/atoms/Login/LoginImg";
import LoginForm from "../components/atoms/Login/LoginForm"


const Login =()=>{


    return(
        <div>
            <LoginImg/>
            <LoginForm/>
        </div>

    );
}
export default Login;