// import { createStore } from 'redux'

// const reducerFn = (state = { counter:0 }, action)=>{

// };
// const store = createStore(reducerFn);
